package dev.crane.exceptions;

public class UnallowedException extends Exception {

	private static final long serialVersionUID = 1L;
	
}
